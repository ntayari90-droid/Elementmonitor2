ساخت APK:
1) پوشه ElementMonitor را در Android Studio (نسخه Koala یا جدیدتر) باز کنید و صبر کنید Gradle همگام شود.
2) برای تست: گوشی را با USB وصل کنید و Run بزنید.
3) برای فایل APK: Build > Build Bundle(s) / APK(s) > Build APK(s).
محتوای اپ همان فایل app/src/main/assets/index.html است؛ برای هر تغییر در فرم، فقط همین فایل را عوض کنید.
